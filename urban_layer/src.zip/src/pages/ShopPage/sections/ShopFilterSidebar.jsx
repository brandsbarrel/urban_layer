import SearchFilterInput from '../../../components/SearchFilterInput/SearchFilterInput';
import CheckboxFilterGroup from '../../../components/CheckboxFilterGroup/CheckboxFilterGroup';
import styles from './ShopFilterSidebar.module.css';

function ShopFilterSidebar({ filters, categories = [], onFilterChange }) {
    const categoryOptions = categories.map((category) => ({
        id: category.slug,
        label: category.name,
    }));

    const phoneOptions = Array.from(
        new Set(categories.flatMap((category) => category.phoneModels || []))
    ).map((phoneModel) => ({
        id: phoneModel,
        label: phoneModel,
    }));

    const toggleCategory = (id) => {
        onFilterChange({
            ...filters,
            category: filters.category === id ? "" : id,
        });
    };

    const togglePhoneModel = (id) => {
        onFilterChange({
            ...filters,
            phoneModel: filters.phoneModel === id ? "" : id,
        });
    };

    return (
        <aside className={styles.sidebar}>
            <SearchFilterInput
                value={filters.search}
                onChange={(search) => onFilterChange({ ...filters, search })}
            />

            <CheckboxFilterGroup
                title="Device"
                options={phoneOptions}
                selectedIds={filters.phoneModel ? [filters.phoneModel] : []}
                onToggle={togglePhoneModel}
            />

            <CheckboxFilterGroup
                title="Category"
                options={categoryOptions}
                selectedIds={filters.category ? [filters.category] : []}
                onToggle={toggleCategory}
            />
        </aside>
    );
}

export default ShopFilterSidebar;
