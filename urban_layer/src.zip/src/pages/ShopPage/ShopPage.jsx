import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useSearchParams } from "react-router-dom";

import Breadcrumb from "../../components/Breadcrumb/Breadcrumb";

import ShopHeroBanner from "./sections/ShopHeroBanner";
import ShopFilterSidebar from "./sections/ShopFilterSidebar";
import ProductGridSection from "./sections/ProductGridSection";
import PromotionalBanner from "./sections/PromotionalBanner";
import RecommendationsSlider from "./sections/RecommendationsSlider";

import styles from "./ShopPage.module.css";

import {
    fetchProductsStart,
    fetchProductsSuccess,
    fetchProductsFailure,
    selectProducts,
} from "../../redux/slices/productSlice";

import { getCategories, getProducts } from "../../services/productsService";

function ShopPage() {
    const dispatch = useDispatch();

    const { items, meta, loading, error } = useSelector(selectProducts);

    const [searchParams] = useSearchParams();
    const initialCategory = searchParams.get("category") || "";

    const [filters, setFilters] = useState({
        search: "",
        category: initialCategory,
        phoneModel: "",
    });
    const [debouncedSearch, setDebouncedSearch] = useState("");
    const [categories, setCategories] = useState([]);

    const [sortBy, setSortBy] = useState("best-sellers");

    const [currentPage, setCurrentPage] = useState(1);

    useEffect(() => {
        const timer = window.setTimeout(() => {
            setDebouncedSearch(filters.search);
            setCurrentPage(1);
        }, 400);

        return () => window.clearTimeout(timer);
    }, [filters.search]);

    useEffect(() => {
        loadProducts();
    }, [currentPage, debouncedSearch, filters.category, filters.phoneModel]);

    useEffect(() => {
        const loadCategories = async () => {
            try {
                setCategories(await getCategories());
            } catch {
                setCategories([]);
            }
        };

        loadCategories();
    }, []);

    const loadProducts = async () => {
        dispatch(fetchProductsStart());

        try {
            const response = await getProducts({
                page: currentPage,
                perPage: 9,
                search: debouncedSearch,
                category: filters.category,
                phoneModel: filters.phoneModel,
            });

            dispatch(fetchProductsSuccess(response));
        } catch (err) {
            dispatch(fetchProductsFailure(err.message));
        }
    };

    const handleFilterChange = (nextFilters) => {
        setFilters(nextFilters);
        setCurrentPage(1);
    };

    return (
        <div className={styles.page}>
            <Breadcrumb
                items={[
                    { label: "Home", path: "/" },
                    { label: "Shop" },
                ]}
            />

            <ShopHeroBanner />

            <div className={styles.contentGrid}>
                <ShopFilterSidebar
                    filters={filters}
                    categories={categories}
                    onFilterChange={handleFilterChange}
                />

                <ProductGridSection
                    products={items}
                    loading={loading}
                    sortBy={sortBy}
                    onSortChange={setSortBy}
                    currentPage={currentPage}
                    totalPages={meta.totalPages}
                    totalItems={meta.totalItems}
                    error={error}
                    onPageChange={setCurrentPage}
                />
            </div>

            <PromotionalBanner />

            <RecommendationsSlider />
        </div>
    );
}

export default ShopPage;
