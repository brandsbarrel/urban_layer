import api from "./api";

export const getProducts = async ({
    page = 1,
    perPage = 20,
    search = "",
    category = "",
    phoneModel = "",
}) => {
    try {
        const response = await api.get("/storefront/catalog/products", {
            params: {
                page,
                perPage,
                search,
                category,
                phoneModel,
            },
        });

        return response.data;
    } catch (error) {
        throw new Error(
            error.response?.data?.message || "Unable to fetch products."
        );
    }
};

export const getCategories = async () => {
    try {
        const response = await api.get("/storefront/catalog/categories");
        return response.data.data.items;
    } catch (error) {
        throw new Error(
            error.response?.data?.message || "Unable to fetch categories."
        );
    }
};
