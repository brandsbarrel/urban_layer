export const NAV_LINKS = [
  { label: 'Home', path: '/' },
  { label: 'Shop', path: '/shop' },
  { label: 'Collections', path: '/collections' },
  { label: 'Accessories', path: '/accessories' },
  { label: 'About', path: '/about' },
];

export const FOOTER_LINKS = {
  shop: [
    { label: 'Shop All', path: '/shop' },
    { label: 'Collections', path: '/collections' },
    { label: 'Accessories', path: '/accessories' },
    { label: 'About Us', path: '/about' },
  ],
  support: [
    { label: 'Privacy Policy', path: '/privacy-policy' },
    { label: 'Terms of Service', path: '/terms-conditions' },
    { label: 'Shipping & Returns', path: '/shipping-policy' },
    { label: 'Contact Us', path: '/contact' },
    { label: 'Wholesale', path: '/wholesale' },
  ],
};